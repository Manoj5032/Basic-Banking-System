<nav class="navbar navbar-expand-lg navbar-light bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#" style="color:green;font-size:300%;">TSF BANK &nbsp&nbsp</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link active" aria-current="page" href="index.php" style="color: antiquewhite;font-size:200%;">  Home</a>
        <a class="nav-link" href="createuser.php" style="color: antiquewhite;font-size:200%;">  Create User</a>
        <a class="nav-link" href="transfermoney.php" style="color: antiquewhite;font-size:200%;">  Transfer Money</a>
        <a class="nav-link" href="transactionhistory.php" style="color: antiquewhite;font-size:200%;">  Transcation History</a>
        
      </div>
    </div>
  </div>
</nav>